function showAlert() {
  alert('Hello from MyJwel Part 1!');
}